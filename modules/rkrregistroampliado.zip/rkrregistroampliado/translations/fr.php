<?php
/*
*
* NOTICE OF LICENSE
*
* You are not authorized to modify, copy or redistribute this file.
* Permissions are reserved by Rekire.com
*
* @author     Rekire - Tecnología web
* @copyright  2018 Rekire.com All right reserved
* @license    Rekire
* @contact    info@rekire.com
*
*/

global $_MODULE;
$_MODULE = array();
$_MODULE['<{rkrregistroampliado}prestashop>rkrregistroampliado_2586e48a3cea658e62d0b90495072820'] = 'Inscription personnalisé';
$_MODULE['<{rkrregistroampliado}prestashop>rkrregistroampliado_77777f4b0c0ffe4600008b00f81dd155'] = 'Ajouter un champ au formulaire d\'inscription';
$_MODULE['<{rkrregistroampliado}prestashop>rkrregistroampliado_0a5fa53f3f20f67f98bd6c3b16df059d'] = 'est requis';
$_MODULE['<{rkrregistroampliado}prestashop>rkrregistroampliado_57078a9f414d2c37775f291ea776f3d6'] = 'Liste des champs';
$_MODULE['<{rkrregistroampliado}prestashop>rkrregistroampliado_460e6376d73ac2b650b1539edf4ae9f5'] = 'Ajouter un nouveau champ';
$_MODULE['<{rkrregistroampliado}prestashop>rkrregistroampliado_39b7775446f89e84a5f6842e3fe2dcb9'] = 'Nouveau champ ajouté avec succès';
$_MODULE['<{rkrregistroampliado}prestashop>rkrregistroampliado_f681330d5e1e69d59fa80054f6c6f16c'] = 'Erreur, le formulaire est incomplet';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarde';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_eff88d54854b0637031f4066736623bc'] = 'Label du champ';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Étiquette d\'aide';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_662d335c75f953ef24fce08d319910c2'] = 'Ordre d\'affichage';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Active';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_189efd19c4153526994a6d7ea5f6f068'] = 'Type de champ';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_40ac89df9ff895152e53bb7ffb13a024'] = 'Champ de texte simple';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_80c9379f5bc0f2b7a6650a0b898dfc94'] = 'Champ de texte long';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_738446aa9e18299c67698b91d8bbbb4e'] = 'Liste de choix, choix unique';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_c8bc55923fbc08ab6176f6ee29aba1b1'] = 'Liste de choix, choix multiple';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_4f8222964f9a317cef99dddc23a121bd'] = 'Case à cocher';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_7a7ab96dd6593c7b8497e4b91b691c44'] = 'Liste de bouton radio';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_c310d750ebfc431206b6585aafbbb56f'] = 'Oui ou Non';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_44749712dbec183e983dcd78a7736c41'] = 'Date (jour, mois, année)';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_a76d4ef5f3f6a672bbfab2865563e530'] = 'Heure (heure, minute)';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_2b0b7c9cbd6d6e9fa6b99aa06e828673'] = 'Date et heure';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_c38266740494aa4980d05c606fccac10'] = 'Groupe client';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_91412465ea9169dfd901dd5e7c96dd99'] = 'Upload';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_e763a9040c9d6d23a871a6a4ce2e91c8'] = 'Liste des valeurs selectionnable';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_076e86bf44b4b5454f766ad4fbce1973'] = 'Groupes client séléctionnable';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_2288496d6834dad07cb91545fe5669fe'] = 'Type de fichiers acceptés';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_08d51ac3e1e4976a72883f2e0b069516'] = 'Sélectionner les types de fichiers acceptés';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_b4350fdd3a45eabd708e6f5244d949d1'] = 'Ordre d\'affichage (classement par ordre croissant)';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_5e23734b5439c1373db5119fca40062c'] = 'Champ requis';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{rkrregistroampliado}prestashop>inputform_8b1a5e28bdfbc2b6f7369b761d5f24fc'] = 'Activer ce champ';
$_MODULE['<{rkrregistroampliado}prestashop>getcontent_7b9324fd1b6cc33da6065e0338fd1828'] = 'Champs personnalisés';
$_MODULE['<{rkrregistroampliado}prestashop>getcontent_8530b6b178b6d58cfe6d837dc06a8b40'] = 'Ce module permet d\'ajouter des champs supplémentaires au formulaire d\'inscription.';
$_MODULE['<{rkrregistroampliado}prestashop>getcontent_4d3e7567f126ecac9b7e61c38874f81f'] = 'Si vous rencontrez des problèmes, des questions ou des demandes, contactez le développeur ';
$_MODULE['<{rkrregistroampliado}prestashop>getcontent_5e4d4f6941cc4d1d711b88a682fcaa5b'] = 'Ajouter un tag';
$_MODULE['<{rkrregistroampliado}prestashop>settings16_4b8227b253d0341a694652640a169370'] = 'INFORMATIONS COMPLÉMENTAIRES';
$_MODULE['<{rkrregistroampliado}prestashop>settings16_4ee29ca12c7d126654bd0e5275de6135'] = 'Liste';
$_MODULE['<{rkrregistroampliado}prestashop>settings16_91b442d385b54e1418d81adc34871053'] = 'Selectionné';
$_MODULE['<{rkrregistroampliado}prestashop>settings16_ae001d03f0da2afea5daee425ad8b1bd'] = 'Type de fichiers acceptés';
$_MODULE['<{rkrregistroampliado}prestashop>settings16_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{rkrregistroampliado}prestashop>settings16_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{rkrregistroampliado}prestashop>settings17_95e3d841a55465e0dcccd1e889a9e825'] = 'Informations additionnels';
$_MODULE['<{rkrregistroampliado}prestashop>settings_95e3d841a55465e0dcccd1e889a9e825'] = 'Informations complémentaire';
$_MODULE['<{rkrregistroampliado}prestashop>settings_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{rkrregistroampliado}prestashop>settings_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{rkrregistroampliado}prestashop>admincustomers_518d776a4fa762df99c7db0de6ad3069'] = 'Mise à jour réussie';
$_MODULE['<{rkrregistroampliado}prestashop>admincustomers_902b0d55fddef6f8d651fe1035b7d4bd'] = 'Erreur';
$_MODULE['<{rkrregistroampliado}prestashop>admincustomers_ae001d03f0da2afea5daee425ad8b1bd'] = 'Type de fichiers acceptés';
$_MODULE['<{rkrregistroampliado}prestashop>admincustomers_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{rkrregistroampliado}prestashop>admincustomers_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{rkrregistroampliado}prestashop>admincustomers_7ee660a19f4da70a992bc6b43184c3c6'] = 'Champs personnalisé';
$_MODULE['<{rkrregistroampliado}prestashop>createaccountform15_1d2e7006048aec610a44d2592586470b'] = 'Autres informations';
$_MODULE['<{rkrregistroampliado}prestashop>createaccountform15_4ee29ca12c7d126654bd0e5275de6135'] = 'Liste';
$_MODULE['<{rkrregistroampliado}prestashop>createaccountform15_91b442d385b54e1418d81adc34871053'] = 'Selectionné';
$_MODULE['<{rkrregistroampliado}prestashop>createaccountform15_ae001d03f0da2afea5daee425ad8b1bd'] = 'Type de fichiers acceptés';
$_MODULE['<{rkrregistroampliado}prestashop>createaccountform15_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{rkrregistroampliado}prestashop>createaccountform15_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{rkrregistroampliado}prestashop>createaccountform16_39fe255cfa4c3c01c0898c2d62e6b07c'] = 'AUTRES CHAMPS';
$_MODULE['<{rkrregistroampliado}prestashop>createaccountform16_4ee29ca12c7d126654bd0e5275de6135'] = 'Liste';
$_MODULE['<{rkrregistroampliado}prestashop>createaccountform16_91b442d385b54e1418d81adc34871053'] = 'Selectionné';
$_MODULE['<{rkrregistroampliado}prestashop>createaccountform16_ae001d03f0da2afea5daee425ad8b1bd'] = 'Type de fichiers acceptés';
$_MODULE['<{rkrregistroampliado}prestashop>createaccountform16_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{rkrregistroampliado}prestashop>createaccountform16_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{rkrregistroampliado}prestashop>_customer-form_4ee29ca12c7d126654bd0e5275de6135'] = 'Liste';
$_MODULE['<{rkrregistroampliado}prestashop>_customer-form_91b442d385b54e1418d81adc34871053'] = 'Sélectionné';
$_MODULE['<{rkrregistroampliado}prestashop>_customer-form_ae001d03f0da2afea5daee425ad8b1bd'] = 'Type de fichiers acceptés';
$_MODULE['<{rkrregistroampliado}prestashop>_customer-form_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{rkrregistroampliado}prestashop>_customer-form_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
$_MODULE['<{rkrregistroampliado}prestashop>displaycustomeraccount16_914bc6173bcb839e0a38429c55b08a6a'] = 'Autres informations';
$_MODULE['<{rkrregistroampliado}prestashop>displaycustomeraccount17_914bc6173bcb839e0a38429c55b08a6a'] = 'Autres informations';
$_MODULE['<{rkrregistroampliado}prestashop>displaycustomeridentityform15_914bc6173bcb839e0a38429c55b08a6a'] = 'Informations supplémentaires';
$_MODULE['<{rkrregistroampliado}prestashop>displaycustomeridentityform16_4ee29ca12c7d126654bd0e5275de6135'] = 'Liste';
$_MODULE['<{rkrregistroampliado}prestashop>displaycustomeridentityform16_91b442d385b54e1418d81adc34871053'] = 'Sélectionné';
$_MODULE['<{rkrregistroampliado}prestashop>displaycustomeridentityform16_ae001d03f0da2afea5daee425ad8b1bd'] = 'Type de fichiers acceptés';
$_MODULE['<{rkrregistroampliado}prestashop>displaycustomeridentityform16_93cba07454f06a4a960172bbd6e2a435'] = 'Oui';
$_MODULE['<{rkrregistroampliado}prestashop>displaycustomeridentityform16_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Non';
