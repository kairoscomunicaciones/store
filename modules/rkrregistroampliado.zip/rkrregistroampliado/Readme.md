Custom Registration
---------------------

* Installation
* License

### Installation
The installation of `RKR Registro ampliado` module is simple and fast.
1. Connect to the administration of your PrestaShop store, access the module page and click Add new module.
2. Click "Choose File" and select the archive module.
3. Click "Load Module".
4. Locate the "RKR Registro ampliado" module and click "Activate".
5. Set the license key in the configuration page.

### License

* NOTICE OF LICENSE

* You are not authorized to modify, copy or redistribute this file.
* Permissions are reserved by Rekire.com

* @author     Rekire - Tecnología web
* @copyright  2018 Rekire.com All right reserved
* @license    Rekire
* @contact    info@rekire.com
