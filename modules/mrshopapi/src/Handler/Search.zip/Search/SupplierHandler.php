<?php

namespace MrAPPs\MrShopApi\Handler\Search;

use PrestaShop\PrestaShop\Adapter\Supplier\SupplierProductSearchProvider;
use PrestaShop\PrestaShop\Core\Product\Search\SortOrder;

class SupplierHandler extends AbstractSearchHandler
{
    protected $supplier_id;

    public function __construct($supplier_id)
    {
        parent::__construct();
        $this->supplier_id = $supplier_id;
    }

    public function getProductSearchQuery()
    {
        return $this->getQuery()
            ->setIdSupplier($this->supplier_id)
            ->setSortOrder(new SortOrder('product', 'position', 'asc'));
    }

    public function getDefaultProductSearchProvider()
    {
        return new SupplierProductSearchProvider(
            $this->getTranslator(),
            $this->supplier_id
        );
    }

    public function getListingLabel()
    {
        return '';
    }
}
