<?php

namespace MrAPPs\MrShopApi\Handler\Search;

use PrestaShop\PrestaShop\Adapter\Search\SearchProductSearchProvider;
use PrestaShop\PrestaShop\Core\Product\Search\SortOrder;

class SearchHandler extends AbstractSearchHandler
{
    protected $search_string;

    public function __construct($search_string)
    {
        parent::__construct();
        $this->search_string = $search_string;
    }

    public function getProductSearchQuery()
    {
        return $this->getQuery()
            ->setSearchString($this->search_string)
            ->setSortOrder(new SortOrder('product', 'position', 'desc'));
    }

    public function getDefaultProductSearchProvider()
    {
        return new SearchProductSearchProvider(
            $this->getTranslator()
        );
    }

    public function getListingLabel()
    {
        return $this->getTranslator()->trans('Search results', [], 'Shop.Theme.Catalog');
    }
}
