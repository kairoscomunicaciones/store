<?php

namespace MrAPPs\MrShopApi\Handler\Search;

use PrestaShop\PrestaShop\Adapter\Category\CategoryProductSearchProvider;
use PrestaShop\PrestaShop\Core\Product\Search\SortOrder;
use Tools;

class CategoryProductHandler extends AbstractSearchHandler
{
    protected $category;

    public function __construct($category)
    {
        parent::__construct();
        $this->category = $category;
    }

    public function getDefaultProductSearchProvider()
    {
        return new CategoryProductSearchProvider(
            $this->getTranslator(),
            $this->category
        );
    }

    public function getProductSearchQuery()
    {
        return $this->getQuery()
            ->setIdCategory($this->category->id)
            ->setSortOrder(
                new SortOrder(
                    'product',
                    Tools::getProductsOrder('by'),
                    Tools::getProductsOrder('way')
                )
            );
    }

    public function getListingLabel()
    {
        return $this->getTranslator()->trans(
            'Category: %category_name%',
            ['%category_name%' => $this->category->name],
            'Shop.Theme.Catalog'
        );
    }
}
