<?php

namespace MrAPPs\MrShopApi\Handler\Search;

use PrestaShop\PrestaShop\Adapter\BestSales\BestSalesProductSearchProvider;
use PrestaShop\PrestaShop\Core\Product\Search\SortOrder;

class BestSalesHandler extends AbstractSearchHandler
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getDefaultProductSearchProvider()
    {
        return new BestSalesProductSearchProvider(
            $this->getTranslator()
        );
    }

    public function getProductSearchQuery()
    {
        return $this->getQuery()
            ->setQueryType('best-sales')
            ->setSortOrder(new SortOrder('product', 'name', 'asc'));
    }

    public function getListingLabel()
    {
        return $this->getTranslator()->trans('Best sellers', [], 'Shop.Theme.Catalog');
    }
}
