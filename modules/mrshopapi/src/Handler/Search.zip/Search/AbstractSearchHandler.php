<?php

namespace MrAPPs\MrShopApi\Handler\Search;

use Context;
use PrestaShop\PrestaShop\Core\Product\Search\ProductSearchQuery;
use PrestaShop\PrestaShop\Core\Product\Search\SortOrder;
use ProductFilterController;
use Tools;

require_once _PS_MODULE_DIR_.'mrshopapi/controllers/front/ProductFilterController.php';

class AbstractSearchHandler
{
    protected $controller;

    protected $translator;

    public function __construct()
    {
        $this->controller = new ProductFilterController();

        $this->controller->init();
        $this->translator = Context::getContext()->getTranslator(true);
    }

    public function getProductSearchVariablesResults($resultsPerPage = 10)
    {
        return $this->controller->getProductSearchVariablesResults($resultsPerPage, $this);
    }

    public function getTranslator()
    {
        return $this->translator;
    }

    public function getController()
    {
        return $this->controller;
    }

    public function getQuery()
    {
        if (($encodedSortOrder = Tools::getValue('order'))) {
            $currentSortOrder = SortOrder::newFromString(
                $encodedSortOrder
            );
        } else {
            $entity = 'product';
            $orderBy = Tools::getProductsOrder('by');
            $orderWay = Tools::getProductsOrder('way');

            $currentSortOrder = new SortOrder($entity, $orderBy, $orderWay);
        }

        $query = new ProductSearchQuery();
        $query->setSortOrder(new SortOrder('product', $currentSortOrder->getField(), $currentSortOrder->getDirection()));

        return $query;
    }
}
