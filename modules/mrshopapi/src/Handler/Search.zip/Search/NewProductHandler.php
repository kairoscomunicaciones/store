<?php

namespace MrAPPs\MrShopApi\Handler\Search;

use PrestaShop\PrestaShop\Adapter\NewProducts\NewProductsProductSearchProvider;
use PrestaShop\PrestaShop\Core\Product\Search\SortOrder;

class NewProductHandler extends AbstractSearchHandler
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getProductSearchQuery()
    {
        return $this->getQuery()
            ->setQueryType('new-products')
            ->setSortOrder(new SortOrder('product', 'date_add', 'desc'));
    }

    public function getDefaultProductSearchProvider()
    {
        return new NewProductsProductSearchProvider(
            $this->getTranslator()
        );
    }

    public function getListingLabel()
    {
        return $this->getTranslator()->trans(
            'New products',
            [],
            'Shop.Theme.Catalog'
        );
    }
}
