<?php

namespace MrAPPs\MrShopApi\Handler\Search;

use PrestaShop\PrestaShop\Adapter\Manufacturer\ManufacturerProductSearchProvider;
use PrestaShop\PrestaShop\Core\Product\Search\SortOrder;
use Tools;

class ManufacturerHandler extends AbstractSearchHandler
{
    protected $manufacturer;

    public function __construct($manufacturer)
    {
        parent::__construct();
        $this->manufacturer = $manufacturer;
    }

    public function getProductSearchQuery()
    {
        return $this->getQuery()
            ->setIdManufacturer($this->manufacturer->id)
            ->setSortOrder(
                new SortOrder(
                    'product',
                    Tools::getProductsOrder('by'),
                    Tools::getProductsOrder('way')
                )
            );
    }

    public function getDefaultProductSearchProvider()
    {
        return new ManufacturerProductSearchProvider(
            $this->getTranslator(),
            $this->manufacturer
        );
    }

    public function getListingLabel()
    {
        return '';
    }
}
