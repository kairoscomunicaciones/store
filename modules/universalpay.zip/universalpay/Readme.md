With this module, you can create an unlimited number of payment methods without writing separate modules.

Features :
Creates an unlimited number of fully customizable methods of payment
Allows you to bind to a payment to carrier
It does not require programming skills

v 3.1.0
+ PrestaShop 1.7.1-1.7.x support

v 3.0.0
+ PrestaShop 1.7.x alpha support

v 2.4.0
+ Added additional input fields values in Success description
- Fixed uninstall

v 2.3.1
+ Updated russian translation
- Fixed false error

v 2.3.0
+ Added payments method setting for virtual/real products
+ Fixed confirmation page breadcrumbs

v 2.2.1
+ Fixed code style

v 2.2.0
+ Assigned cart rule to payment
+ Added multistore

v 2.1.0
+ Added AdvancedPaymentOptions hook
+ Added french translation

v 2.0.5
+ Fixed date_add and date_upd fields

v 2.0.4
+ You can use additional input fields in mail temlplates. E.g. {up_name}

v 2.0.0
+ Added input fields before order confirmation
+ BugFix text after confirmation
+ Refractoring

v 1.9
+ BugFix Remove paysystemes based on customer group
+ BugFix Confirmation button

v 1.8
+ rewritten to support PrestaShop 1.6
+ text improvment
+ %order_number% return order reference
+ Removed translations, since they no longer are valid, many strings changed.

v 1.7
+ added success message displayed in order details page. you can remove it on Modules/Positions tab
+ added user groups filter

v 1.4
+ carrier updating fixed

v 1.3
+ added confirmation button on payment systems page

v 1.2
+ added payment success page
+ added created order state
