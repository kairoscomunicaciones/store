
[![GitHub license](https://img.shields.io/github/license/UniversalPay/prestashop_beta)](https://github.com/UniversalPay/prestashop_beta/blob/master/LICENSE)
![Version](https://img.shields.io/badge/version-1.0-informational)

# Universal Pay PrestaShop Plugin
This plugin is provided for Universal Pay merchants using PrestaShop V1.6 and V1.7. 

Got a question? Visit https://www.universalpay.es/contacto/ or email integraciones_es@evopayments.com for support.

## Installation Guides

For instructions on how to install the plugin on PrestaShop please use the following links:
* [PrestaShop 1.6](https://github.com/UniversalPay/Prestashop_Plugin/wiki/PrestaShop-1.6)
* [PrestaShop 1.7](https://github.com/UniversalPay/Prestashop_Plugin/wiki/PrestaShop-1.7)
