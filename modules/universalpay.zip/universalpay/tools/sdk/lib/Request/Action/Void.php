<?php

namespace Payments;

class RequestActionVoid extends RequestActionRefund {}
