<?php

namespace Payments;

class ResponseSuccess extends Response {
    
}
