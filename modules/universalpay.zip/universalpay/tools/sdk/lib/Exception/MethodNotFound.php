<?php

namespace Payments;

class PaymentsExceptionMethodNotFound extends \Exception {
    
}
