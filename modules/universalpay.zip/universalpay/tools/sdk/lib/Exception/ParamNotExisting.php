<?php

namespace Payments;

class PaymentsExceptionParamNotExisting extends \Exception {
    
}
