<?php

namespace Payments;

class PaymentsExceptionConfigurationEndpointNotSet extends \Exception {
    
}
