<?php

namespace Payments;

class PaymentsExceptionProcessDataNotSet extends \Exception {
    
}
