<?php

namespace Payments;

class PaymentsExceptionParamNotSet extends \Exception {
    
}
