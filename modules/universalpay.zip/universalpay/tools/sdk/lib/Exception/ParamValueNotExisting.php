<?php

namespace Payments;

class PaymentsExceptionParamValueNotExisting extends \Exception {
    
}
