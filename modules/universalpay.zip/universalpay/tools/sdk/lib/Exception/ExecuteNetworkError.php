<?php

namespace Payments;

class PaymentsExceptionExecuteNetworkError extends \Exception {
    
}
