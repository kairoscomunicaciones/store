Module V5.X.X compatible with PrestaShop V1.7.x.x
Module V2.X.X compatible with PrestaShop V1.6.x.x
