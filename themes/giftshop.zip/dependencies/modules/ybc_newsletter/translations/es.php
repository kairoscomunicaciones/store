<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ybc_newsletter}prestashop>ybc_newsletter_979d2c45d5a881e49a3d1e7b5905859c'] = 'Responsive Newsletter Popup';
