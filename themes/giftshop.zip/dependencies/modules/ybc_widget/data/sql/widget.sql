INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('77','displayTopColumn','1','1','1','1','bn1.png','','#','1','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('78','displayTopColumn','1','1','1','1','bn2.png','','#','2','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('79','displayTopColumn','1','1','1','1','bn3.png','','#','3','');


