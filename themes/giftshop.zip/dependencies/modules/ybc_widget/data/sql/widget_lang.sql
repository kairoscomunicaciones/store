INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('77','_ID_LANG_','Birthday Gifts','25%','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('78','_ID_LANG_','Valentine Gifts','15%','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('79','_ID_LANG_','Chirstmas Gifts','30%','');


