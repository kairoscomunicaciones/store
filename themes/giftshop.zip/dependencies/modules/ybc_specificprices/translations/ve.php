<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_6757f7617a4fd9cb27c341b6ca735508'] = 'Mostrar productos específicos con descuento en la página de inicio';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_b78a3223503896721cca1303f776159b'] = 'Título';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_4241591ecae342ac08eaad6776a9a2a6'] = 'ID de producto';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_90d58ea5be9cf79b11854112c9e8470f'] = 'Separados por una coma. Ej: 1,3,4';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_93cba07454f06a4a960172bbd6e2a435'] = 'Sí';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_3cb570a281fdf81f60f32cdfed505ff6'] = 'Se requiere';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_0a5fa53f3f20f67f98bd6c3b16df059d'] = 'Se requiere';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_a2dfd34e4a55c47d43aedebb87a7ed58'] = 'no puede ser mayor a 100Mb';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_998b344cff693ad388a14ba89b1523c7'] = 'Es invalido';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_1ea31f288865ad8bd640f38acb0742ad'] = 'Los ID de producto no tienen un formato válido';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_ca9d4e7efbc4c150afeb389ef5e62121'] = 'ya existe. Intenta cambiar el nombre del archivo y vuelve a subirlo';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_dc75b70fb639a9b40637265045bebf79'] = 'No se puede cargar el archivo';
$_MODULE['<{ybc_specificprices}prestashop>ybc_specificprices_7cc92687130ea12abb80556681538001'] = 'Ocurrió un error durante el proceso de carga de la imagen.';
$_MODULE['<{ybc_specificprices}prestashop>renderjs_628b7db04235f228d40adc671413a8c8'] = 'día';
$_MODULE['<{ybc_specificprices}prestashop>renderjs_896c55cc5e46fab38ce9f51ebf7bfcd3'] = 'hora';
$_MODULE['<{ybc_specificprices}prestashop>renderjs_d8bd79cc131920d5de426f914d17405a'] = 'minuto';
$_MODULE['<{ybc_specificprices}prestashop>renderjs_74459ca3cf85a81df90da95ff6e7a207'] = 'segundo';
$_MODULE['<{ybc_specificprices}prestashop>renderjs_44fdec47036f482b68b748f9d786801b'] = 'días';
$_MODULE['<{ybc_specificprices}prestashop>renderjs_c760237f74bcc7e3f90ad956086edb66'] = 'horas';
$_MODULE['<{ybc_specificprices}prestashop>renderjs_1442a7b6e2c20b27775175eecba84dac'] = 'minutos';
$_MODULE['<{ybc_specificprices}prestashop>renderjs_975a85a4ffa56e23c70e2bbeaf405ac7'] = 'segundos';
