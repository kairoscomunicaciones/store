<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ybc_manufacturer}prestashop>ybc_manufacturer_dd935a2e301d8b711dfb997b7ca8b6af'] = 'Control deslizante de fabricantes/marcas';
$_MODULE['<{ybc_manufacturer}prestashop>ybc_manufacturer_be33693fe48707f86b4634a52685d518'] = 'Mostrar lista de fabricantes/marcas en la página de inicio';
$_MODULE['<{ybc_manufacturer}prestashop>ybc_manufacturer_15ab5f09f7d7bc5f02ce0890ffc0eaf6'] = 'Nuestras marcas';
$_MODULE['<{ybc_manufacturer}prestashop>ybc_manufacturer_62bf91d10fcc5222472473420155ef30'] = 'Debe ingresar el título del bloque';
$_MODULE['<{ybc_manufacturer}prestashop>ybc_manufacturer_020f6d39338174865873e28de2b81107'] = 'Debe ingresar el número de fabricantes para mostrar';
$_MODULE['<{ybc_manufacturer}prestashop>ybc_manufacturer_254f642527b45bc260048e30704edb39'] = 'Configuración';
$_MODULE['<{ybc_manufacturer}prestashop>ybc_manufacturer_b22c8f9ad7db023c548c3b8e846cb169'] = 'Título de bloque';
$_MODULE['<{ybc_manufacturer}prestashop>ybc_manufacturer_e5f63e6e10f8107fbbfa1e2dd03656f6'] = 'Número de fabricantes a mostrar';
$_MODULE['<{ybc_manufacturer}prestashop>ybc_manufacturer_d652df3fc2c60f7d58bf51d23e7e8abe'] = 'Mostrar nombre del fabricante';
$_MODULE['<{ybc_manufacturer}prestashop>ybc_manufacturer_93cba07454f06a4a960172bbd6e2a435'] = 'Sí';
$_MODULE['<{ybc_manufacturer}prestashop>ybc_manufacturer_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{ybc_manufacturer}prestashop>ybc_manufacturer_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
